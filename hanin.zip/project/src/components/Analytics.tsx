import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import { format, subDays } from 'date-fns';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { ComponentProps, WaterUsageData, MonthlyData, AnalyticsHighlight } from '../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const Analytics: React.FC<ComponentProps> = ({ state }) => {
  const last7Days = useMemo(() => 
    Array.from({ length: 7 }, (_, i) => ({
      date: subDays(new Date(), i),
      usage: Math.floor(Math.random() * (300 - 150) + 150),
      quality: Math.floor(Math.random() * (98 - 90) + 90)
    })).reverse(),
    []
  );
  
  const waterUsageData: WaterUsageData = {
    labels: last7Days.map(day => format(day.date, 'MMM dd')),
    datasets: [
      {
        label: 'Water Usage (Liters)',
        data: last7Days.map(day => day.usage),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
      },
      {
        label: 'Water Quality (%)',
        data: last7Days.map(day => day.quality),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        fill: true,
      }
    ]
  };

  const monthlyData: MonthlyData = {
    totalUsage: '32,470L',
    avgQuality: '94.8%',
    efficiency: '97.2%',
    savings: '12.5%'
  };

  const highlights: AnalyticsHighlight[] = useMemo(() => {
    const peakDay = last7Days.reduce((max, day) => day.usage > max.usage ? day : max);
    const lowestDay = last7Days.reduce((min, day) => day.usage < min.usage ? day : min);
    const avgUsage = Math.round(last7Days.reduce((sum, day) => sum + day.usage, 0) / last7Days.length);

    return [
      {
        date: peakDay.date,
        usage: peakDay.usage,
        description: `Peak usage day: ${format(peakDay.date, 'MMMM dd')} (${peakDay.usage}L)`
      },
      {
        date: lowestDay.date,
        usage: lowestDay.usage,
        description: `Lowest usage day: ${format(lowestDay.date, 'MMMM dd')} (${lowestDay.usage}L)`
      },
      {
        date: new Date(),
        usage: avgUsage,
        description: `Average daily usage: ${avgUsage}L`
      }
    ];
  }, [last7Days]);

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Water Usage & Quality Analytics',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value: number) => `${value}${value > 90 ? '%' : 'L'}`
        }
      },
    },
  };

  return (
    <div className="elegant-card p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">System Analytics</h2>
        <p className="text-slate-600">Monthly performance metrics and trends</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="stat-card">
          <h3 className="text-lg font-semibold text-slate-700">Monthly Usage</h3>
          <p className="text-3xl font-bold text-blue-600">{monthlyData.totalUsage}</p>
          <p className="text-sm text-slate-500">Total consumption</p>
        </div>
        
        <div className="stat-card">
          <h3 className="text-lg font-semibold text-slate-700">Quality Index</h3>
          <p className="text-3xl font-bold text-green-600">{monthlyData.avgQuality}</p>
          <p className="text-sm text-slate-500">Average purity</p>
        </div>
        
        <div className="stat-card">
          <h3 className="text-lg font-semibold text-slate-700">Efficiency</h3>
          <p className="text-3xl font-bold text-amber-600">{monthlyData.efficiency}</p>
          <p className="text-sm text-slate-500">System performance</p>
        </div>

        <div className="stat-card">
          <h3 className="text-lg font-semibold text-slate-700">Water Savings</h3>
          <p className="text-3xl font-bold text-purple-600">{monthlyData.savings}</p>
          <p className="text-sm text-slate-500">vs. last month</p>
        </div>
      </div>
      
      <div className="h-[400px]">
        <Line options={options} data={waterUsageData} />
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h3 className="text-lg font-semibold text-blue-800 mb-2">Monthly Highlights</h3>
        <ul className="space-y-2 text-sm text-blue-700">
          {highlights.map((highlight, index) => (
            <li key={index}>• {highlight.description}</li>
          ))}
          <li>• Water quality maintained above 90% throughout the month</li>
        </ul>
      </div>
    </div>
  );
};

export default Analytics;